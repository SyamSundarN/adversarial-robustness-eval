"""
The two attacks. Both work on pixels between 0 and 1 and never move a pixel
by more than eps. Our main setting is eps = 8/255.
"""
import torch
import torch.nn.functional as F


def fgsm(model, x, y, eps=8 / 255):
    """One step: push every pixel by eps in the direction that makes the model more wrong."""
    x = x.clone().detach().requires_grad_(True)
    loss = F.cross_entropy(model(x), y)
    grad, = torch.autograd.grad(loss, x)
    x_adv = x + eps * grad.sign()
    return x_adv.clamp(0, 1).detach()


def pgd(model, x, y, eps=8 / 255, steps=20, alpha=None, random_start=True):
    """FGSM repeated in small steps, pulled back inside the +-eps box after each one."""
    alpha = alpha if alpha is not None else 2.5 * eps / steps
    x = x.clone().detach()
    x_adv = x.clone()
    if random_start:
        x_adv = (x_adv + torch.empty_like(x).uniform_(-eps, eps)).clamp(0, 1)

    for _ in range(steps):
        x_adv.requires_grad_(True)
        loss = F.cross_entropy(model(x_adv), y)
        grad, = torch.autograd.grad(loss, x_adv)
        x_adv = x_adv.detach() + alpha * grad.sign()
        x_adv = torch.min(torch.max(x_adv, x - eps), x + eps)  # stay within eps of the original
        x_adv = x_adv.clamp(0, 1)
    return x_adv.detach()


def make_attack(name, eps=8 / 255, steps=20):
    """Turn a name into something evaluate() can call."""
    if name == "none":
        return None
    if name == "fgsm":
        return lambda m, x, y: fgsm(m, x, y, eps)
    if name == "pgd":
        return lambda m, x, y: pgd(m, x, y, eps, steps)
    raise ValueError(f"unknown attack: {name}")
