"""
Checks that our numbers hold up.

  1. eps sweep:   make the attacker stronger step by step (2, 4, 8, 16 /255)
  2. AutoAttack:  four strong attacks together, the field's standard final check
  3. transfer:    attack the baseline, test those images on the defended model
                  (an attacker who doesn't have our model)

  python benchmark.py            500 test images, ~10 min on a T4
"""
import argparse
import csv
import os

import torchattacks

from attacks import pgd
from common import evaluate, get_test_loader, load_resnet20, set_seed

EPS = 8 / 255
ADV_PATH = "checkpoints/adv_resnet20.pt"


def pgd_at(eps):
    return lambda m, x, y: pgd(m, x, y, eps, 20)


def autoattack(model, loader):
    aa = torchattacks.AutoAttack(model, norm="Linf", eps=EPS, version="standard",
                                 n_classes=10, seed=0)
    return evaluate(model, loader, attack=lambda m, x, y: aa(x, y))


def show(rows, path):
    keys = list(rows[0].keys())
    print("\n" + " | ".join(keys))
    for r in rows:
        print(" | ".join(str(r.get(k, "-")) for k in keys))
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        w.writerows(rows)
    print(f"saved {path}")


def main(args):
    set_seed(0)
    os.makedirs("results", exist_ok=True)
    loader = get_test_loader(args.n, batch_size=100)
    base = load_resnet20()
    models = [("Baseline", base)]
    if os.path.exists(ADV_PATH):
        models.append(("Adv. trained", load_resnet20(ADV_PATH)))
    else:
        print("(no trained model yet, so only the baseline is checked)")

    # 1. eps sweep
    print("eps sweep ...")
    sweep = []
    for e in [0, 2, 4, 8, 16]:
        r = {"eps_x255": e}
        for name, m in models:
            r[name] = round(evaluate(m, loader, None if e == 0 else pgd_at(e / 255)), 1)
        sweep.append(r)
    show(sweep, "results/eps_sweep.csv")

    # 2. AutoAttack and 3. transfer
    rows = []
    for name, m in models:
        print(f"AutoAttack on {name} ...")
        rows.append({"model": name,
                     "pgd20_%": round(evaluate(m, loader, pgd_at(EPS)), 1),
                     "autoattack_%": round(autoattack(m, loader), 1),
                     "transfer_%": "-"})
    if len(models) == 2:
        rows[1]["transfer_%"] = round(
            evaluate(models[1][1], loader, pgd_at(EPS), attack_model=base), 1)
    show(rows, "results/benchmark.csv")

    # TODO (after midterm): add the C&W attack here
    # TODO (after midterm): run everything on all 10,000 test images


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Group 8 - eps sweep, AutoAttack, transfer attack")
    ap.add_argument("--n", type=int, default=500, help="number of test images")
    main(ap.parse_args())
