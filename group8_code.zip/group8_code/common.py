import os
import random

import numpy as np
import torch
import torch.nn as nn
import torchvision
import torchvision.transforms as T

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
CLASSES = ("plane", "car", "bird", "cat", "deer", "dog", "frog", "horse", "ship", "truck")

# The pretrained weights expect normalized images. We do the normalizing inside
# the model, so attacks can work on plain pixels between 0 and 1.
MEAN = (0.4914, 0.4822, 0.4465)
STD = (0.2023, 0.1994, 0.2010)


def set_seed(seed=0):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


class Normalize(nn.Module):
    def __init__(self, mean, std):
        super().__init__()
        self.register_buffer("mean", torch.tensor(mean).view(1, 3, 1, 1))
        self.register_buffer("std", torch.tensor(std).view(1, 3, 1, 1))

    def forward(self, x):
        return (x - self.mean) / self.std


def load_resnet20(weights_path=None):
    net = torch.hub.load("chenyaofo/pytorch-cifar-models", "cifar10_resnet20",
                         pretrained=(weights_path is None), trust_repo=True, verbose=False)
    model = nn.Sequential(Normalize(MEAN, STD), net)
    if weights_path is not None:
        model.load_state_dict(torch.load(weights_path, map_location="cpu"))
    return model.to(DEVICE).eval()


class HFCifar10(torch.utils.data.Dataset):
    def __init__(self, train, transform):
        from datasets import load_dataset
        self.ds = load_dataset("uoft-cs/cifar10", split="train" if train else "test")
        self.transform = transform

    def __len__(self):
        return len(self.ds)

    def __getitem__(self, i):
        row = self.ds[i]
        return self.transform(row["img"].convert("RGB")), row["label"]


def cifar10(train, transform, data_dir="./data"):
    if os.path.isdir(os.path.join(data_dir, "cifar-10-batches-py")):
        return torchvision.datasets.CIFAR10(data_dir, train=train, download=False, transform=transform)
    return HFCifar10(train, transform)


def get_test_loader(n=1000, batch_size=250):
    ds = cifar10(False, T.ToTensor())
    ds = torch.utils.data.Subset(ds, range(min(n, len(ds))))
    return torch.utils.data.DataLoader(ds, batch_size=batch_size, shuffle=False, num_workers=2)


def get_train_loader(batch_size=128):
    tf = T.Compose([T.RandomCrop(32, padding=4), T.RandomHorizontalFlip(), T.ToTensor()])
    ds = cifar10(True, tf)
    return torch.utils.data.DataLoader(ds, batch_size=batch_size, shuffle=True,
                                       num_workers=2, drop_last=True)


def evaluate(model, loader, attack=None, attack_model=None):
    model.eval()
    correct = total = 0
    for x, y in loader:
        x, y = x.to(DEVICE), y.to(DEVICE)
        if attack is not None:
            x = attack(attack_model or model, x, y)
        with torch.no_grad():
            correct += (model(x).argmax(1) == y).sum().item()
        total += y.numel()
    return 100.0 * correct / total
