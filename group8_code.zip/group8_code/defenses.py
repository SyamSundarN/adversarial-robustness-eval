"""
Defense A: adversarial training (retrain on attacked images).
Defense B: clean the image before the model sees it (JPEG, 4-bit colour),
           plus the BPDA trick so we can attack through the filter.
"""
import io
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from PIL import Image

from attacks import fgsm, pgd
from common import DEVICE, evaluate


# ---------- Defense B: input filters ----------

def jpeg_filter(x, quality=75):
    """Save each image as a JPEG and load it back. JPEG throws away fine detail."""
    out = []
    for img in x.detach().cpu():
        arr = (img.permute(1, 2, 0).numpy() * 255).round().astype(np.uint8)
        buf = io.BytesIO()
        Image.fromarray(arr).save(buf, format="JPEG", quality=quality)
        dec = np.array(Image.open(buf)).astype(np.float32) / 255.0
        out.append(torch.from_numpy(dec).permute(2, 0, 1))
    return torch.stack(out).to(x.device)


def bit_depth_filter(x, bits=4):
    """Round every colour to 16 levels instead of 256, so tiny changes get rounded away."""
    levels = 2 ** bits - 1
    return torch.round(x * levels) / levels


class FilteredModel(nn.Module):
    """
    The baseline with a filter in front of it.

    Going forward, the model really sees the filtered image. Going backward, we
    pretend the filter isn't there (that's BPDA), so an attacker can still get
    a useful gradient through it.
      - attack the plain baseline, score this model  -> naive attacker
      - attack this model, score this model           -> adaptive (BPDA) attacker
    """

    def __init__(self, model, filt):
        super().__init__()
        self.model, self.filt = model, filt

    def forward(self, x):
        x_filtered = self.filt(x)
        return self.model(x + (x_filtered - x).detach())


# ---------- Defense A: adversarial training ----------

def adversarial_training(model, train_loader, test_loader, epochs=10, eps=8 / 255,
                         lr=0.01, save_path="checkpoints/adv_resnet20.pt"):
    """
    Fine-tune the pretrained model on attacked images, using fast FGSM training
    (random start + one FGSM step, from Wong et al. 2020).

    TODO (after midterm): stronger PGD-based training for 30 epochs.
    """
    opt = torch.optim.SGD(model.parameters(), lr=lr, momentum=0.9, weight_decay=5e-4)
    sched = torch.optim.lr_scheduler.OneCycleLR(opt, max_lr=lr, epochs=epochs,
                                                steps_per_epoch=len(train_loader))
    check = lambda m, x, y: pgd(m, x, y, eps, steps=10)
    best, log = -1.0, []
    start = time.time()

    for epoch in range(1, epochs + 1):
        model.train()
        for x, y in train_loader:
            x, y = x.to(DEVICE), y.to(DEVICE)

            # 1. attack this batch with the current model
            model.eval()
            delta = torch.empty_like(x).uniform_(-eps, eps)
            x_adv = fgsm(model, (x + delta).clamp(0, 1), y, eps=1.25 * eps)
            x_adv = torch.min(torch.max(x_adv, x - eps), x + eps).clamp(0, 1)
            model.train()

            # 2. learn to get the attacked images right
            loss = F.cross_entropy(model(x_adv), y)
            opt.zero_grad()
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 5.0)  # stops early updates from wrecking the pretrained weights
            opt.step()
            sched.step()

        # 3. see how well it resists PGD now
        clean = evaluate(model, test_loader)
        robust = evaluate(model, test_loader, attack=check)
        minutes = (time.time() - start) / 60
        log.append({"epoch": epoch, "clean_acc": round(clean, 1),
                    "pgd10_acc": round(robust, 1), "minutes": round(minutes, 1)})
        print(f"epoch {epoch:2d}/{epochs} | clean {clean:5.1f}% | PGD-10 {robust:5.1f}% | {minutes:5.1f} min")

        # 4. keep the most robust version (fast training can suddenly lose its robustness)
        if robust > best:
            best = robust
            torch.save(model.state_dict(), save_path)

    print(f"saved the best model (PGD-10 {best:.1f}%) to {save_path}")
    return log
