"""
Runs the experiments.

  python main.py baseline    accuracy of the pretrained model, before and after FGSM / PGD
  python main.py train       Defense A: adversarial training (~10 min on a Colab T4)
  python main.py compare     baseline vs Defense A vs the JPEG filter (naive and BPDA attacker)
  python main.py demo        one image: the clean picture, the noise, the attacked picture

--n sets how many test images to use (default 1000, 10000 = the whole test set).
Tables go to results/, the trained model to checkpoints/.
"""
import argparse
import csv
import os
from functools import partial

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch

from attacks import make_attack, pgd
from common import (CLASSES, DEVICE, evaluate, get_test_loader, get_train_loader,
                    load_resnet20, set_seed)
from defenses import FilteredModel, adversarial_training, jpeg_filter

EPS = 8 / 255
ADV_PATH = "checkpoints/adv_resnet20.pt"
os.makedirs("results", exist_ok=True)
os.makedirs("checkpoints", exist_ok=True)


def save_table(rows, path):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    keys = list(rows[0].keys())
    widths = [max(len(k), *(len(str(r[k])) for r in rows)) for k in keys]
    print("\n" + " | ".join(k.ljust(w) for k, w in zip(keys, widths)))
    for r in rows:
        print(" | ".join(str(r[k]).ljust(w) for k, w in zip(keys, widths)))
    print(f"\nsaved {path}")


def load_adv_model():
    if not os.path.exists(ADV_PATH):
        print("(no trained model yet, run `python main.py train` first; skipping Defense A)")
        return None
    return load_resnet20(ADV_PATH)


def cmd_baseline(args):
    loader = get_test_loader(args.n)
    base = load_resnet20()
    row = {"model": "Baseline ResNet-20"}
    for name, col in [("none", "clean_%"), ("fgsm", "fgsm_%"), ("pgd", "pgd20_%")]:
        row[col] = round(evaluate(base, loader, attack=make_attack(name, EPS)), 1)
    save_table([row], "results/baseline.csv")


def cmd_train(args):
    model = load_resnet20()  # start from the pretrained model, not from scratch
    log = adversarial_training(model, get_train_loader(), get_test_loader(500),
                               epochs=args.epochs, eps=EPS, save_path=ADV_PATH)
    save_table(log, "results/training_log.csv")


def cmd_compare(args):
    loader = get_test_loader(args.n)
    base = load_resnet20()
    adv = load_adv_model()
    jpeg = FilteredModel(base, partial(jpeg_filter, quality=75))
    fgsm_a, pgd_a = make_attack("fgsm", EPS), make_attack("pgd", EPS)

    def row(name, model, naive_from=None):
        # for a filter, naive_from is the plain baseline: the attacker ignores the filter
        print(f"evaluating {name} ...")
        r = {"model": name,
             "clean_%": round(evaluate(model, loader), 1),
             "fgsm_%": round(evaluate(model, loader, fgsm_a, naive_from), 1),
             "pgd20_%": round(evaluate(model, loader, pgd_a, naive_from), 1),
             "bpda_%": "-"}
        if naive_from is not None:
            r["bpda_%"] = round(evaluate(model, loader, pgd_a), 1)  # attacker plans around the filter
        return r

    rows = [row("Baseline", base)]
    if adv is not None:
        rows.append(row("Defense A: adversarial training", adv))
    rows.append(row("Defense B: JPEG (q=75)", jpeg, naive_from=base))
    # TODO (in progress): add the 4-bit filter row and try different filter strengths
    # TODO (in progress): bar chart of this table
    save_table(rows, "results/compare.csv")


def cmd_demo(args):
    ds = get_test_loader(10000, batch_size=1).dataset
    base = load_resnet20()
    adv = load_adv_model()
    jpeg = FilteredModel(base, partial(jpeg_filter, quality=75))

    def predict(model, img):
        with torch.no_grad():
            p = torch.softmax(model(img), 1)[0]
        return p.argmax().item(), f"{CLASSES[p.argmax()]} ({100 * p.max():.0f}%)"

    def story(i):
        x, y = ds[i]
        x, y = x.unsqueeze(0).to(DEVICE), torch.tensor([y], device=DEVICE)
        x_adv = pgd(base, x, y, EPS)
        # (step, model, prediction, should it be right?)
        steps = [("1. Normal", "Baseline", predict(base, x), True),
                 ("2. PGD attack", "Baseline", predict(base, x_adv), False)]
        if adv is not None:
            steps.append(("3. Defense A", "Adv. trained", predict(adv, pgd(adv, x, y, EPS)), True))
        steps.append(("4. JPEG, naive", "Baseline + JPEG", predict(jpeg, x_adv), True))
        steps.append(("5. JPEG, BPDA", "Baseline + JPEG", predict(jpeg, pgd(jpeg, x, y, EPS)), False))
        ok = all((p[0] == y.item()) == right for _, _, p, right in steps)
        return x, y, x_adv, steps, ok

    # by default, show the first image where every step comes out the way we expect
    index = args.index
    if index < 0:
        index = next((i for i in range(300) if story(i)[4]), 0)
    x, y, x_adv, steps, _ = story(index)

    print(f"\ntest image #{index}, true label: {CLASSES[y.item()]}")
    for s, m, (_, text), _ in steps:
        print(f"  {s:16s} {m:16s} -> {text}")

    noise = (0.5 + (x_adv - x)[0] / (2 * EPS)).clamp(0, 1)  # grey = unchanged, blown up so you can see it
    fig, ax = plt.subplots(1, 3, figsize=(9, 3.6))
    for a, img, title in zip(ax, [x[0], noise, x_adv[0]],
                             [f"original\n{steps[0][2][1]}", "noise (amplified)",
                              f"attacked\n{steps[1][2][1]}"]):
        a.imshow(img.permute(1, 2, 0).cpu().numpy())
        a.set_title(title, fontsize=10)
        a.axis("off")
    fig.suptitle(f"true label: {CLASSES[y.item()]}   |   eps = 8/255", fontsize=11)
    plt.tight_layout()
    out = f"results/demo_{index}.png"
    plt.savefig(out, dpi=150)
    print(f"saved {out}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Group 8 - adversarial robustness (midterm)")
    ap.add_argument("command", choices=["baseline", "train", "compare", "demo"])
    ap.add_argument("--n", type=int, default=1000, help="number of test images")
    ap.add_argument("--epochs", type=int, default=10, help="adversarial training epochs")
    ap.add_argument("--index", type=int, default=-1, help="demo image (-1 = pick one automatically)")
    args = ap.parse_args()
    set_seed(0)
    {"baseline": cmd_baseline, "train": cmd_train,
     "compare": cmd_compare, "demo": cmd_demo}[args.command](args)
